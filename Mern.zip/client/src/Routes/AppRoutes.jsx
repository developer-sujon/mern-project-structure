//external Lib  imports
import React from "react";
import { Routes, Route } from "react-router-dom";

function AppRoutes() {
  return <Routes></Routes>;
}

export default AppRoutes;
