//external Lib  imports
import AppRoutes from "./router/AppRoutes";

//internal Lib  imports

function App() {
  return (
    <div className="App">
      <AppRoutes />
    </div>
  );
}

export default App;
